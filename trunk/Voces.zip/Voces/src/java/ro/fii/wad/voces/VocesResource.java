package ro.fii.wad.voces;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import javax.ejb.Stateless;

import javax.ws.rs.Path;
import javax.ws.rs.GET;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import parserRDF.ParserRDF;

/**
 * REST Web Service
 *
 * @author mkuchtiak
 */

@Stateless
@Path("/VocesWS")
public class VocesResource {
    private static int fileId = 0;
    private static Map<String, String> vocabularyList = new HashMap<String, String>();

    static {
        vocabularyList.put("foaf", "http://xmlns.com/foaf/spec/index.rdf");
        vocabularyList.put("doap", "http://usefulinc.com/ns/doap#");
        vocabularyList.put("dcmi", "http://dublincore.org/2008/01/14/dcterms.rdf");
    }

    @GET
    @Produces("application/xml")
    public String getVocabulary(@QueryParam("name") String name) {
        String vocabularyURI = vocabularyList.get(name);
        if (vocabularyURI != null) {
            return ParserRDF.ParseRDFFile(vocabularyURI, fileId++);
        }
        return "";
    }

    @GET
    @Produces("text/plain")
    public String getVocabularyList() {
        Set<String> keys = vocabularyList.keySet();//"foaf doap dcmi";http://xmlns.com/foaf/spec/index.rdf, " + "http://usefulinc.com/ns/doap#, " + "http://dublincore.org/2008/01/14/dcterms.rdf";
        
        String result = "" ;//"foaf doap dcmi";

        for (String s : keys) {
            result += s + " ";
        }
        
        return result;
    }

//    /**
//     * PUT method for updating an instance of VocesResource
//     * @param content representation for the resource
//     * @return an HTTP response with content of the updated or created resource.
//     */
//    @GET
//    @Produces("text/html")
//    public String getXml() {
//        return "<html><body><h1>" + "Hello " + nameStorage.getName() + "</h1></body></html>";
//    }

//    /**
//     * PUT method for updating an instance of VocesResource
//     * @param content representation for the resource
//     * @return an HTTP response with content of the updated or created resource.
//     */
//    @PUT
//    @Consumes("text/plain")
//    public void putXml(String content) {
//        nameStorage.setName(content);
//    }
}
